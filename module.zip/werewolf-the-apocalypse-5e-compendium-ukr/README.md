A compendium of player options from the corebook of Werewolf the Apocalypse 5th edition for use with Veilza and Rayji96's unofficial 5th edition system.

Dark Pack

<img width="300" height="308" alt="darkpack_logo2" src="https://images.ctfassets.net/u73tyf0fa8v1/3oBTHBZk9XmfcBlUPylvFh/673e4a6b14566548c03424ddf627b944/darkpack_logo2.png?w=3840&q=75" />

We have made every effort to keep the Dark Pack guidelines as posted at Dark Pack Agreement.

Portions of the materials are the copyrights and trademarks of Paradox Interactive AB, and are used with permission. All rights reserved. For more information please visit worldofdarkness.com.
